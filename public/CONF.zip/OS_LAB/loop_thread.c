#include <stdio.h>
#include <pthread.h>
struct Student {
int id;
char name[20];
float marks;
};
struct Student s[10];
int n;
void* printStudent(void* arg){
int idx=*(int*)arg;
printf("ID: %d, Name: %s, Marks: %.2f\n",s[idx].id,s[idx].name,s[idx].marks);
return NULL;
}
int main(){
printf("Enter number of students: ");
scanf("%d",&n);
for(int i=0;i<n;i++){
s[i].id=i+1;
printf("Enter Name and Marks for Student %d: ",i+1);
scanf("%s %f",s[i].name,&s[i].marks);
}
pthread_t tid[n]; int idx[n];
for(int i=0;i<n;i++){
idx[i]=i;
pthread_create(&tid[i],NULL,printStudent,&idx[i]);
}
for(int i=0;i<n;i++) 
pthread_join(tid[i],NULL);
return;
}