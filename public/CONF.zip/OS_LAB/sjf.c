#include <stdio.h>

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    int bt[n], wt[n], tat[n], p[n];
    
    // Input Burst Times
    printf("Enter Burst Time for each process:\n");
    for(int i = 0; i < n; i++) {
        printf("P%d: ", i+1);
        scanf("%d", &bt[i]);
        p[i] = i+1; // store process numbers
    }

    // Sort processes by burst time (Ascending)
    for(int i = 0; i < n-1; i++) {
        for(int j = 0; j < n-i-1; j++) {
            if(bt[j] > bt[j+1]) {
                int temp = bt[j];
                bt[j] = bt[j+1];
                bt[j+1] = temp;

                int temp2 = p[j];
                p[j] = p[j+1];
                p[j+1] = temp2;
            }
        }
    }

    // Waiting time
    wt[0] = 0;
    for(int i = 1; i < n; i++) {
        wt[i] = wt[i-1] + bt[i-1];
    }

    // Turnaround time
    for(int i = 0; i < n; i++) {
        tat[i] = wt[i] + bt[i];
    }

    // Output Result Table
    float avgWT = 0, avgTAT = 0;
    printf("\nProcess\tBurst\tWaiting\tTurnaround\n");
    for(int i = 0; i < n; i++) {
        printf("P%d\t %d\t %d\t %d\n", p[i], bt[i], wt[i], tat[i]);
        avgWT += wt[i];
        avgTAT += tat[i];
    }

    avgWT /= n;
    avgTAT /= n;

    printf("\nAverage Waiting Time: %.2f", avgWT);
    printf("\nAverage Turnaround Time: %.2f\n", avgTAT);

    printf("\nGantt Chart: |");
    for(int i = 0; i < n; i++) {
        printf(" P%d |", p[i]);
    }
    printf("\n");

    return 0;
}
