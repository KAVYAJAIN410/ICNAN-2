#include <stdio.h>

int main() {
    int n;
    printf("Enter number of processes: ");
    scanf("%d", &n);

    int bt[n], wt[n], tat[n];
    
    // Input Burst Times
    printf("Enter Burst Time for each process:\n");
    for(int i = 0; i < n; i++) {
        printf("P%d: ", i+1);
        scanf("%d", &bt[i]);
    }

    // Waiting time
    wt[0] = 0; // First process waits 0
    for(int i = 1; i < n; i++) {
        wt[i] = wt[i-1] + bt[i-1];
    }

    // Turnaround time = WT + BT
    for(int i = 0; i < n; i++) {
        tat[i] = wt[i] + bt[i];
    }

    // Output Table
    printf("\nProcess\tBurst\tWaiting\tTurnaround\n");
    float avgWT = 0, avgTAT = 0;
    
    for(int i = 0; i < n; i++) {
        printf("P%d\t %d\t %d\t %d\n", i+1, bt[i], wt[i], tat[i]);
        avgWT += wt[i];
        avgTAT += tat[i];
    }

    avgWT /= n;
    avgTAT /= n;

    printf("\nAverage Waiting Time: %.2f", avgWT);
    printf("\nAverage Turnaround Time: %.2f\n", avgTAT);

    printf("\nGantt Chart: |");
    for(int i = 0; i < n; i++) {
        printf(" P%d |", i+1);
    }
    printf("\n");

    return 0;
}
