#include <stdio.h>

int main() {
    int n, start, len;
    int block[100] = {0}; // 0: free, 1: allocated
    int i, j, k;

    printf("Enter number of blocks in disk: ");
    scanf("%d", &n);

    while (1) {
        printf("\nEnter starting block & length of file: ");
        scanf("%d %d", &start, &len);

        if(start + len > n) {
            printf("Not enough blocks... File cannot be allocated!\n");
            continue;
        }

        // check free blocks
        for(j = start; j < start + len; j++) {
            if(block[j] == 1) break;
        }

        if(j == start + len) {
            for(k = start; k < start + len; k++)
                block[k] = 1;
            printf("File allocated successfully!\n");
        } else {
            printf("File allocation failed. Block %d already allocated\n", j);
        }

        printf("Allocate another file? (1/0): ");
        scanf("%d", &i);
        if(i == 0) break;
    }

    return 0;
}
