#include <stdio.h>

int main() {
    int block[50], index[50], i, j, n, ind, length;

    for(i = 0; i < 50; i++)
        block[i] = 0;

    printf("Enter number of blocks already allocated: ");
    scanf("%d", &n);

    printf("Enter already allocated block numbers: ");
    for(i = 0; i < n; i++) {
        scanf("%d", &j);
        block[j] = 1;
    }

    printf("Enter index block number: ");
    scanf("%d", &ind);

    if(block[ind] == 1) {
        printf("Index block already allocated!\n");
        return 0;
    }

    block[ind] = 1;

    printf("Enter number of blocks needed for the file: ");
    scanf("%d", &length);

    printf("Enter block numbers: ");
    for(i = 0; i < length; i++) {
        scanf("%d", &index[i]);
        if(block[index[i]] == 1) {
            printf("Block %d already allocated!\n", index[i]);
            return 0;
        }
    }

    for(i = 0; i < length; i++)
        block[index[i]] = 1;

    printf("\nFile Successfully Allocated!\n");
    return 0;
}
