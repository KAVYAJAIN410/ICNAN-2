#include <stdio.h>
#include <pthread.h>
int num;
void* oddEven(void* arg) {
if(num%2==0) printf("%d is Even\n",num);
else printf("%d is Odd\n",num);
return NULL;
}
void* prime(void* arg) {
int prime=1;
if(num<=1) prime=0;
for(int i=2;i*i<=num;i++)
if(num%i==0) { prime=0; break; }
if(prime) printf("%d is Prime\n",num);
else printf("%d is Not Prime\n",num);
return NULL;
}
void* palindrome(void* arg) {
int n=num,rev=0,d;
while(n>0){d=n%10; rev=rev*10+d; n/=10;}
if(rev==num) printf("%d is Palindrome\n",num);
else printf("%d is Not Palindrome\n",num);
return NULL;
}
int main() {
pthread_t t1,t2,t3;
printf("Enter a number: ");
scanf("%d",&num);
pthread_create(&t1,NULL,oddEven,NULL);
pthread_create(&t2,NULL,prime,NULL);
pthread_create(&t3,NULL,palindrome,NULL);
pthread_join(t1,NULL);
pthread_join(t2,NULL);
pthread_join(t3,NULL);
return 0;
}