#include <stdio.h>

int main() {
    int frames, pages;
    printf("Enter number of frames: ");
    scanf("%d", &frames);
    printf("Enter number of pages: ");
    scanf("%d", &pages);

    int page[pages], frame[frames], freq[frames];
    int faults = 0;

    for(int i=0; i<frames; i++) {
        frame[i] = -1;
        freq[i] = 0;
    }

    printf("Enter page reference string:\n");
    for(int i=0; i<pages; i++)
        scanf("%d", &page[i]);

    for(int i=0; i<pages; i++) {
        int found = 0;

        for(int j=0; j<frames; j++) {
            if(frame[j] == page[i]) {
                freq[j]++;
                found = 1;
                break;
            }
        }

        if(!found) {
            int minIndex = 0;
            for(int j=1; j<frames; j++) {
                if(freq[j] < freq[minIndex])
                    minIndex = j;
            }
            frame[minIndex] = page[i];
            freq[minIndex] = 1;
            faults++;
        }

        printf("\nFrames: ");
        for(int j=0; j<frames; j++)
            printf("%d ", frame[j]);
    }

    printf("\n\nTotal Page Faults: %d\n", faults);
    return 0;
}
