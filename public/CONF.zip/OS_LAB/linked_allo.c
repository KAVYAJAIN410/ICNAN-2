#include <stdio.h>

int blocks[50], n;

void allocate(int start, int len) {
    int i;
    if(blocks[start] == 1) {
        printf("Block already allocated!\n");
        return;
    }
    for(i = start; i < start + len; i++) {
        if(blocks[i] == 0)
            blocks[i] = 1;
        else {
            printf("Block %d already allocated!\n", i);
            break;
        }
    }
    printf("File allocated successfully!\n");
}

int main() {
    int i, start, len, choice;

    for(i = 0; i < 50; i++)
        blocks[i] = 0;

    while(1) {
        printf("\nEnter starting block & length of file: ");
        scanf("%d %d", &start, &len);

        allocate(start, len);

        printf("Allocate another file? (1/0): ");
        scanf("%d", &choice);
        if(choice == 0) break;
    }

    return 0;
}
