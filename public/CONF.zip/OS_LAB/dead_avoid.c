#include <stdio.h>
#include <stdbool.h>

int main() {
    int n, m;
    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter number of resource types: ");
    scanf("%d", &m);

    int alloc[n][m], max[n][m], avail[m], need[n][m];
    
    printf("\nEnter Allocation Matrix:\n");
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            scanf("%d", &alloc[i][j]);

    printf("\nEnter Max Matrix:\n");
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            scanf("%d", &max[i][j]);

    printf("\nEnter Available Resources:\n");
    for(int i = 0; i < m; i++)
        scanf("%d", &avail[i]);

    // Calculate NEED Matrix
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            need[i][j] = max[i][j] - alloc[i][j];

    bool finish[n];
    for(int i = 0; i < n; i++) finish[i] = false;

    int safeSeq[n];
    int idx = 0;

    // Safety Algorithm
    for(int k = 0; k < n; k++) {
        for(int i = 0; i < n; i++) {
            if (!finish[i]) {
                bool possible = true;
                for(int j = 0; j < m; j++) {
                    if (need[i][j] > avail[j]) {
                        possible = false;
                        break;
                    }
                }
                if (possible) {
                    for(int j = 0; j < m; j++)
                        avail[j] += alloc[i][j];

                    safeSeq[idx++] = i;
                    finish[i] = true;
                }
            }
        }
    }

    // Check if all processes finished
    bool safe = true;
    for(int i = 0; i < n; i++) {
        if (!finish[i]) {
            safe = false;
            break;
        }
    }

    if (safe) {
        printf("\nSystem is in a SAFE STATE.\nSafe Sequence: ");
        for(int i = 0; i < n; i++)
            printf("P%d ", safeSeq[i]);
    } else {
        printf("\nSystem is NOT in a safe state! Deadlock may occur.\n");
    }

    return 0;
}
