#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
int mail=0;
void * routine(void *arg){
    for(int i=0;i<10000000;i++){
        mail++;
        
    }
}
int main(){
   pthread_t p1,p2;
   pthread_create(&p1,NULL,&routine,NULL);
   pthread_create(&p2,NULL,&routine,NULL);
   pthread_join(p1,NULL);
  pthread_join(p2,NULL);
  
   printf("%d",mail);
   
}