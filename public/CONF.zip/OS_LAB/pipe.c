#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd[2];
    char message[] = "Hello from Parent!";
    char buffer[50];

    pipe(fd); // Create pipe

    if (fork() == 0) {
        // Child Process
        close(fd[1]); // Close write end
        read(fd[0], buffer, sizeof(buffer));
        printf("Child Received: %s\n", buffer);
        close(fd[0]);
    } else {
        // Parent Process
        close(fd[0]); // Close read end
        write(fd[1], message, strlen(message) + 1);
        close(fd[1]);
    }
    return 0;
}
