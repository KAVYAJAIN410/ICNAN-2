#include <stdio.h>

int main() {
    int frames, pages;
    printf("Enter number of frames: ");
    scanf("%d", &frames);
    printf("Enter number of pages: ");
    scanf("%d", &pages);

    int page[pages], frame[frames], last_used[frames];
    int time = 0, faults = 0;

    for(int i=0; i<frames; i++) {
        frame[i] = -1;
        last_used[i] = -1;
    }

    printf("Enter page reference string:\n");
    for(int i=0; i<pages; i++)
        scanf("%d", &page[i]);

    for(int i=0; i<pages; i++) {
        int found = 0, pos = -1;

        for(int j=0; j<frames; j++) {
            if(frame[j] == page[i]) {
                found = 1;
                last_used[j] = time++;
                break;
            }
        }

        if(!found) {
            int lruIndex = 0;
            for(int j=1; j<frames; j++) {
                if(last_used[j] < last_used[lruIndex])
                    lruIndex = j;
            }
            frame[lruIndex] = page[i];
            last_used[lruIndex] = time++;
            faults++;
        }

        printf("\nFrames: ");
        for(int j=0; j<frames; j++)
            printf("%d ", frame[j]);
    }

    printf("\n\nTotal Page Faults: %d\n", faults);
    return 0;
}
