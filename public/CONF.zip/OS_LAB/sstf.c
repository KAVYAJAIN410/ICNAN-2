#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main() {
    int n, head;
    printf("Enter number of disk requests: ");
    scanf("%d", &n);

    int req[n];
    bool done[n];

    printf("Enter request sequence:\n");
    for(int i = 0; i < n; i++)
        scanf("%d", &req[i]), done[i] = false;

    printf("Enter initial head position: ");
    scanf("%d", &head);

    int seek = 0;

    for(int i = 0; i < n; i++) {
        int min = 9999, index = -1;

        for(int j = 0; j < n; j++) {
            if(!done[j] && abs(req[j] - head) < min) {
                min = abs(req[j] - head);
                index = j;
            }
        }

        seek += abs(req[index] - head);
        head = req[index];
        done[index] = true;
    }

    printf("\nTotal Seek Time (SSTF): %d\n", seek);
    return 0;
}
