#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t mutex;      // For protecting read_count variable
sem_t wrt;        // For providing mutual exclusion to writers

int read_count = 0;
int shared_data = 0; // Shared resource

void *reader(void *arg) {
    int id = *((int *)arg);
    while (1) {
        sem_wait(&mutex);      // lock read_count update
        read_count++;
        if (read_count == 1)
            sem_wait(&wrt);    // first reader blocks writers
        sem_post(&mutex);

        printf("Reader %d is reading shared_data = %d\n", id, shared_data);
        sleep(1);

        sem_wait(&mutex);
        read_count--;
        if (read_count == 0)
            sem_post(&wrt);    // last reader unlocks writers
        sem_post(&mutex);

        sleep(rand() % 3);
    }
    return NULL;
}

void *writer(void *arg) {
    int id = *((int *)arg);
    while (1) {
        sem_wait(&wrt); // Writer enters critical section
        shared_data++;
        printf("\tWriter %d modified shared_data to %d\n", id, shared_data);
        sleep(2);
        sem_post(&wrt); // Writer leaves

        sleep(rand() % 4);
    }
    return NULL;
}

int main() {
    int i;
    pthread_t rtid[5], wtid[2];
    int reader_id[5] = {1,2,3,4,5};
    int writer_id[2] = {1,2};

    sem_init(&mutex, 0, 1);
    sem_init(&wrt, 0, 1);

    // Creating threads
    for (i = 0; i < 5; i++)
        pthread_create(&rtid[i], NULL, reader, &reader_id[i]);

    for (i = 0; i < 2; i++)
        pthread_create(&wtid[i], NULL, writer, &writer_id[i]);

    // main thread waits (simulate infinite run)
    pthread_exit(NULL);

    return 0;
}
