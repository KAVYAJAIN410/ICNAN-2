#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>
#define BUFFER_SIZE 10
char a[BUFFER_SIZE];
int data=65,front=0,rear=0,count=0;
sem_t full, empty,mutex;
void *producer(void *);
void *consumer(void *);
int main()
{

pthread_t producerthread;
pthread_t consumerthread;
sem_init(&full, 0, 0);
sem_init(&empty, 0, BUFFER_SIZE);
sem_init(&mutex, 0, 1);
pthread_create(&producerthread, NULL, producer, NULL);
pthread_create(&consumerthread, NULL, consumer, NULL);
pthread_exit(NULL);
return 0;
}
void *producer(void *t)
{
int r;
while(1)
{
printf("\nProducer wants to produce item");
sem_wait(&empty);
sem_wait(&mutex);
a[rear]=data;
rear=(rear+1)%BUFFER_SIZE;
count++;
printf("\nproducer produces %c & total element in buffer %d",data,count);
 data++;
sem_post(&mutex);
 sem_post(&full);
 r=rand();
r=r%7+1;
sleep(r);

}
return(NULL);
}
void *consumer(void *e)
{
while(1)
{
int r;
printf("\nConsumer wants to consume");
sem_wait(&full);
sem_wait(&mutex);
front=(front+1)%BUFFER_SIZE;
count--;
printf("\nConsumer consume the data %c and total buffer in buffer is %d",a[front-1],count);
sem_post(&mutex);
sem_post(&empty);
 r=rand();
r=r%7+1;
sleep(r);
 }

return(NULL);
}