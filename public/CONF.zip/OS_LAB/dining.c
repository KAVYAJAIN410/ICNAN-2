#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#define N 5 // Number of philosophers

sem_t chopstick[N]; // Semaphores for chopsticks

void *philosopher(void *num) {
    int id = *((int *)num);

    while (1) {
        printf("Philosopher %d is thinking...\n", id);
        sleep(1);

        if (id % 2 == 0) {
            sem_wait(&chopstick[id]);               // pick left
            sem_wait(&chopstick[(id + 1) % N]);    // pick right
        } else {
            sem_wait(&chopstick[(id + 1) % N]);    // pick right
            sem_wait(&chopstick[id]);              // pick left
        }

        printf("Philosopher %d is eating using chopsticks %d and %d\n",
               id, id, (id + 1) % N);
        sleep(2);

        sem_post(&chopstick[id]);                  // release left
        sem_post(&chopstick[(id + 1) % N]);        // release right

        printf("Philosopher %d finished eating.\n", id);
        sleep(1);
    }
}

int main() {
    pthread_t thread_id[N];
    int philosopher_id[N];

    for (int i = 0; i < N; i++) {
        sem_init(&chopstick[i], 0, 1);
        philosopher_id[i] = i;
    }

    for (int i = 0; i < N; i++) {
        pthread_create(&thread_id[i], NULL, philosopher,
                        &philosopher_id[i]);
    }

    pthread_exit(NULL);
}
