#include <stdio.h>
#include <stdlib.h>

int main() {
    int n, head, disk_size;
    printf("Enter number of requests: ");
    scanf("%d", &n);

    int req[n];
    printf("Enter request sequence:\n");
    for(int i = 0; i < n; i++)
        scanf("%d", &req[i]);

    printf("Enter initial head position: ");
    scanf("%d", &head);
    printf("Enter disk size (max cylinder number): ");
    scanf("%d", &disk_size);

    int direction;
    printf("Enter direction (1 for right, 0 for left): ");
    scanf("%d", &direction);

    // Sort requests
    for (int i = 0; i < n - 1; i++)
        for (int j = i + 1; j < n; j++)
            if (req[i] > req[j]) {
                int temp = req[i];
                req[i] = req[j];
                req[j] = temp;
            }

    int seek = 0, pos = 0;

    // Find pivot index
    for (int i = 0; i < n; i++)
        if (req[i] >= head) {
            pos = i;
            break;
        }

    printf("\nOrder of servicing (SCAN): ");

    if (direction) {  // move right
        for (int i = pos; i < n; i++) {
            printf("%d ", req[i]);
            seek += abs(req[i] - head);
            head = req[i];
        }
        // move to disk end
        seek += abs((disk_size - 1) - head);
        head = disk_size - 1;
        // go left
        for (int i = pos - 1; i >= 0; i--) {
            printf("%d ", req[i]);
            seek += abs(req[i] - head);
            head = req[i];
        }
    } else {  // move left first
        for (int i = pos - 1; i >= 0; i--) {
            printf("%d ", req[i]);
            seek += abs(req[i] - head);
            head = req[i];
        }
        // move to 0
        seek += abs(head - 0);
        head = 0;
        // go right
        for (int i = pos; i < n; i++) {
            printf("%d ", req[i]);
            seek += abs(req[i] - head);
            head = req[i];
        }
    }

    printf("\nTotal Seek Time (SCAN): %d\n", seek);

    return 0;
}
