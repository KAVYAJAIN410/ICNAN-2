#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

#define SHM_SIZE 1024

int main() {
    int shmid;
    char *shm;
    key_t key = ftok("shmfile", 65);

    shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);
    shm = (char*) shmat(shmid, NULL, 0);

    if (fork() == 0) {
        // Child process: Read from shared memory
        sleep(2);
        printf("Child Read: %s\n", shm);
        shmdt(shm);
    } else {
        // Parent: Write to shared memory
        strcpy(shm, "Hello from Shared Memory!");
        printf("Parent Wrote Message\n");
        sleep(3);
        shmdt(shm);
        shmctl(shmid, IPC_RMID, NULL); // Remove shared memory
    }

    return 0;
}
